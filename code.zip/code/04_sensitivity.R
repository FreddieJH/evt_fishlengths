

for(selected_dist  in c("tnorm", "gamma", "lnorm")){

p_simulation_bias <- 
   posteriors_max_summary |> 
   filter(str_detect(filename, "_efs_")) %>%
   filter(str_detect(filename, selected_dist)) %>% 
   mutate(gamma_shape = as.numeric(str_extract(filename, "(?<=shape)[0-9]+$"))) %>% 
   left_join(gamma_priors) %>% 
     left_join(scenarios) %>% 
   left_join(scenarios_truemax) %>% 
    ggplot(aes(x = est_max_fit, y = true_max, col = as.factor(k))) +
    geom_abline(slope = 1) +
    geom_point() +
    geom_errorbarh(aes(xmin = est_max_lwr, xmax = est_max_upr)) +
    facet_grid(n_lambda ~ gamma_shape, scales = "free", 
               labeller = labeller(
                   n_lambda = function(x) paste0("n = ", x)
               )) +
    theme_minimal(20) +
    theme(
        panel.border = element_rect(color = "black", fill = NA, linewidth = 1), 
        legend.position = "bottom",
        legend.direction = "horizontal", 
        plot.background = element_rect(fill = "white") 
    ) +
    guides(color = guide_legend(override.aes = list(size = 5), nrow = 1)) + 
    labs(
        x = expression("Estimated "~L[max]~ "(cm)"),
        y = expression("True " ~ L[max]~ "(cm)"),
        color = "# samples (k):"
    ) 

ggsave(
    filename = paste0("results/figures/p_simulation_bias_", selected_dist,".png"),
    plot = p_simulation_bias,
    height = 10,
    width = 15
)

}
