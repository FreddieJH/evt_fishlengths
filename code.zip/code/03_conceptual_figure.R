# Figure 1: Conceptual figure comparing the two methods of estimating maximum length of a fish

# Script requirements  --------------------------------------------------------------

source("code/00a_truncnorm_functions.R")
source("code/00b_model_functions.R")
source("code/00c_expectedmax_functions.R")
library(tidyverse)
library(patchwork)
library(evd)

# Script parameters  --------------------------------------------------------------

concept_popln_mean <- 50
concept_popln_sd <- 16
concept_popln_truncation <- 0 # positive body lengths only
concept_k <- 6 # number of samples (i.e., maxima values)
concept_n <- 50 # sample size per sample
save_figures <- TRUE

evt_colour <- "orange"
efs_colour <- "pink"
efs_colour_dark <- "#f66b6b"
data_colour1 <- "purple"
data_colour2 <- "blue"

# Underlying population  -------------------------------------------------

# Random sampling of truncated normal distribution
set.seed(1)
concept_popln <- rtnorm(
    n = 10000,
    mean = concept_popln_mean,
    sd = concept_popln_sd,
    a = concept_popln_truncation
)

# PDF of the underlying population
# concept_popln_pdf <-
#     tibble(size = 0:150) |>
#     mutate(p = dtnorm(size, mean = concept_popln_mean, sd = concept_popln_sd, a = concept_popln_truncation))

# get k maxima values from the underlying distribution
concept_maxima <- replicate(
    concept_k,
    max(sample(x = concept_popln, size = concept_n))
)

# concept_underlying <-
#     ggplot(concept_popln_pdf) +
#     geom_line(aes(x = size, y = p), linewidth = 1) +
#     labs(x = "Body Size (cm)", y = "Density") +
#     theme_minimal(20) +
#     theme(legend.position = "none", axis.ticks.y = element_blank(), axis.text.y = element_blank(), axis.title.y = element_blank())

# Sampling method --------------------------------------------------------

samples_df <- map_dfr(1:concept_k, function(i) {
    # Generate random sample sizes between 30 and 200
    nn <- sample(10:100, 1)

    # Generate truncated normal data
    sample_data <- rtnorm(
        nn,
        a = 0,
        mean = concept_popln_mean,
        sd = concept_popln_sd
    )

    threshold <- sample(1:4, 1)

    # Create and return data frame for this sample
    tibble(
        sample_id = i,
        value = sample_data,
        is_max = sample_data == max(sample_data),
        near_max = rank(-value, ties.method = "max") <= threshold,
        n = nn, # Store sample size for reference
        rank = case_when(
            !is_max & !near_max ~ "low",
            !is_max & near_max ~ "high",
            is_max & near_max ~ "highest"
        )
    )
})

concept_samples <-
    ggplot(samples_df, aes(x = value)) +
    geom_dotplot(
        aes(fill = rank),
        method = "histodot",
        # binpositions = "all",
        dotsize = 1,
        binwidth = 5
    ) +
    scale_fill_manual(
        values = c(
            "low" = "transparent",
            "high" = data_colour1,
            "highest" = data_colour2
        )
    ) +
    facet_wrap(
        ~sample_id,
        nrow = 1,
        labeller = labeller(sample_id = function(value) {
            paste0("Sample #", value)
        })
    ) +
    labs(x = "Body Size (cm)", y = "Count") +
    theme_classic(base_size = 20) +
    theme(
        legend.position = "none",
        axis.ticks.y = element_blank(),
        axis.text.y = element_blank(),
        axis.title.y = element_blank()
    )


# Extreme value theory (EVT) method -----------------------------------------

concept_evt_fit_path <- "data/model_fits/concept_evt_fit.rds"
if (!file.exists(concept_evt_fit_path)) {
    concept_evt_fit <- fit_maxima_model(
        maxima = samples_df %>% filter(is_max) %>% pull(value),
        type = "evt"
    )
    saveRDS(concept_evt_fit, concept_evt_fit_path)
} else {
    concept_evt_fit <- readRDS(concept_evt_fit_path)
}

concept_evt_summary_path <- "data/model_summaries/concept_evt_pdf_summary.csv"
if (!file.exists(concept_evt_summary_path)) {
    concept_evt_pdf_summary <-
        concept_evt_fit$draws |>
        expand_grid(size = 0:180) |>
        mutate(
            pdf = pmap_dbl(
                .l = list(x = size, loc = mu, scale = sigma, shape = xi),
                .f = evd::dgev
            )
        ) |>
        summarise(
            p_fit = mean(pdf),
            p_lwr = quantile(pdf, 0.025),
            p_upr = quantile(pdf, 0.975),
            .by = size
        )
    write_csv(concept_evt_pdf_summary, concept_evt_summary_path)
} else {
    concept_evt_pdf_summary <- read_csv(
        concept_evt_summary_path,
        show_col_types = FALSE
    )
}

concept_evt_expmax <-
    concept_evt_fit$draws |>
    mutate(
        pdf = pmap_dbl(
            .l = list(
                p = 1 - (1 / concept_k),
                loc = mu,
                scale = sigma,
                shape = xi
            ),
            .f = evd::qgev
        )
    ) |>
    summarise(
        p_fit = mean(pdf)
    ) %>%
    as.numeric()

concept_evt <-
    concept_evt_pdf_summary |>
    ggplot() +
    geom_ribbon(
        aes(x = size, ymin = p_lwr, ymax = p_upr),
        fill = evt_colour,
        alpha = 0.3
    ) +
    geom_line(
        aes(x = size, y = p_fit),
        linewidth = 2,
        lty = "solid",
        col = evt_colour
    ) +
    geom_point(
        aes(x = concept_maxima, y = 0),
        col = "black",
        fill = data_colour2,
        size = 4,
        pch = 21,
        data = tibble()
    ) +
    geom_vline(xintercept = concept_evt_expmax, col = "black", lty = "dotted") +
    labs(x = "Body Size (cm)", y = "Density") +
    theme_classic(20) +
    facet_grid(
        cols = vars(1),
        labeller = labeller(.cols = function(x) paste("Extreme Value Theory"))
    ) +
    theme(
        legend.position = "none",
        axis.ticks.y = element_blank(),
        axis.text.y = element_blank(),
        axis.title.y = element_blank()
    )

# Exact finite sampling (EFS) method  -----------------------------------------

concept_efs_fit_path <- "data/model_fits/concept_efs_fit.rds"
if (!file.exists(concept_efs_fit_path)) {
    concept_efs_fit <- fit_maxima_model(
        maxima = samples_df %>% filter(is_max) %>% pull(value),
        type = "efs",
        gamma_shape = 5,
        gamma_rate = 0.1
    )
    saveRDS(concept_efs_fit, concept_efs_fit_path)
} else {
    concept_efs_fit <- readRDS(concept_efs_fit_path)
}

concept_efs_summary_path <- "data/model_summaries/concept_efs_pdf_summary.csv"
if (!file.exists(concept_efs_summary_path)) {
    concept_efs_pdf_summary <-
        concept_efs_fit$draws |>
        expand_grid(size = 0:180) |>
        mutate(
            pdf = pmap_dbl(
                .l = list(x = size, mean = mu, sd = sigma),
                .f = dtnorm
            )
        ) |>
        summarise(
            p_fit = mean(pdf),
            p_lwr = quantile(pdf, 0.025),
            p_upr = quantile(pdf, 0.975),
            .by = size
        )
    write_csv(concept_efs_pdf_summary, concept_efs_summary_path)
} else {
    concept_efs_pdf_summary <- read_csv(
        concept_efs_summary_path,
        show_col_types = FALSE
    )
}

concept_efs_summary_max_path <- "data/model_summaries/concept_efs_pdfmax_summary.csv"
if (!file.exists(concept_efs_summary_max_path)) {
    concept_efs_pdfmax_summary <-
        concept_efs_fit$draws |>
        expand_grid(size = 0:180) |>
        mutate(
            pdf = pmap_dbl(
                .l = list(
                    x = size,
                    distr = "tnorm",
                    n = lambda,
                    par1 = mu,
                    par2 = sigma
                ),
                .f = g_max
            )
        ) |>
        summarise(
            p_fit = mean(pdf),
            p_lwr = quantile(pdf, 0.025),
            p_upr = quantile(pdf, 0.975),
            .by = size
        )
    write_csv(concept_efs_pdfmax_summary, concept_efs_summary_max_path)
} else {
    concept_efs_pdfmax_summary <- read_csv(
        concept_efs_summary_max_path,
        show_col_types = FALSE
    )
}

concept_efs_expmax <-
    concept_efs_fit$draws |>
    mutate(
        pdf = pmap_dbl(
            .l = list(
                distr = "tnorm",
                n = lambda,
                par1 = mu,
                par2 = sigma,
                p = 1 - (1 / concept_k)
            ),
            .f = inverse_G_x
        )
    ) |>
    summarise(
        p_fit = mean(pdf)
    ) %>%
    as.numeric()

concept_efs <-
    concept_efs_pdf_summary |>
    ggplot() +
    geom_ribbon(
        aes(x = size, ymin = p_lwr, ymax = p_upr),
        fill = efs_colour_dark,
        alpha = 0.3
    ) +
    geom_line(
        aes(x = size, y = p_fit),
        linewidth = 1,
        lty = "solid",
        col = efs_colour_dark
    ) +
    geom_ribbon(
        aes(x = size, ymin = p_lwr, ymax = p_upr),
        fill = efs_colour,
        alpha = 0.3,
        data = concept_efs_pdfmax_summary
    ) +
    geom_line(
        aes(x = size, y = p_fit),
        linewidth = 1,
        lty = "dashed",
        col = efs_colour,
        data = concept_efs_pdfmax_summary
    ) +
    geom_point(
        aes(x = concept_maxima, y = 0),
        col = "black",
        fill = data_colour2,
        size = 4,
        pch = 21,
        data = tibble()
    ) +
    geom_vline(xintercept = concept_efs_expmax, col = "black", lty = "dotted") +
    labs(x = "Body Size (cm)", y = "Density") +
    theme_classic(20) +
    facet_grid(
        cols = vars(1),
        labeller = labeller(.cols = function(x) paste("Exact Finite-Sample"))
    ) +
    theme(
        legend.position = "none",
        axis.ticks.y = element_blank(),
        axis.text.y = element_blank(),
        axis.title.y = element_blank()
    )


# Figure 1 ---------------------------------------------------------------------

concept_plot <-
    # concept_underlying +
    concept_samples +
    concept_evt +
    concept_efs +
    plot_layout(design = "AA\nBC", heights = c(2, 5)) +
    plot_annotation(tag_levels = "A")


ggsave(
    filename = "results/figures/p_concept.png",
    plot = concept_plot,
    height = 10,
    width = 14
)
