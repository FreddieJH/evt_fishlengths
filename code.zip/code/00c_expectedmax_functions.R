library(evd)


# PDF(x) = f(x) = Pr(X = x)
f_x <- function(x, distr, par1, par2) {
  get(paste0("d", distr))(x, par1, par2)
}

# CDF(x) = F(x) = Pr(X <= x)
F_x <- function(x, distr, par1, par2) {
  get(paste0("p", distr))(x, par1, par2)
}

# the PDF of the maxima = g(x_max) = Pr(X_n = x) = n * (F(x)^n-1) * f(x)
g_max <- function(x, distr, n, par1, par2) {
  f_x_clean <- function(x) f_x(x, distr = distr, par1 = par1, par2 = par2)
  F_x_clean <- function(x) F_x(x, distr = distr, par1 = par1, par2 = par2)

  # g_max <- function(x) n * (F_x(x)^(n - 1)) * f_x(x)

  # avoiding very small pdf and cdf values
  log_f_max <- log(n) + (n - 1) * log(F_x_clean(x)) + log(f_x_clean(x))
  return(exp(log_f_max))
}

# the CDF of the maxima = G(x_max) = F(x)^n
G_max <- function(x, distr, n, par1, par2) {
  F_x_clean <- function(x) F_x(x, distr = distr, par1 = par1, par2 = par2)
  return(F_x_clean(x)^n)
}

# q_max <- function(distr, n, par1, par2, q, interval_lwr = 0, interval_upr = 300) {
#   # Find the value of x such that G_max(x) = 0.95
#   # This is equivalent to finding the qth percentile of the maximum distribution
#
#   find_q <- function(x) G_max(x, distr = distr, n = n, par1 = par1, par2 = par2) - q
#   res <- uniroot(find_q, c(interval_lwr, interval_upr))$root
#   return(res)
# }

# used to calculate the value at a given perentile of the G_max()
inverse_G_x <- function(
  distr,
  n,
  par1,
  par2,
  p,
  interval_lwr = 1,
  interval_upr = 1000
) {
  uniroot(
    function(x) G_max(x, distr = distr, n = n, par1 = par1, par2 = par2) - p,
    lower = interval_lwr,
    upper = interval_upr
  )$root
}

expected_max <- function(distr, n, par1, par2) {
  integrand <- function(x) {
    x * g_max(x, distr = distr, n = n, par1 = par1, par2 = par2)
  }
  upper_bound <- get(paste0("q", distr))(0.9999999999999, par1, par2)
  integrate(integrand, lower = 0, upper = upper_bound, rel.tol = 1e-6)$value
}

# calc_dist_pars <- function(dist = c("gamma", "tnorm", "lnorm"), mean, var){
#   if (dist == "gamma") {
#     shape <- (mean^2) / var
#     rate <- mean / var # rate is 1/scale
#     return(list(shape, rate))
#     } else if (dist == "tnorm") {
#     mu <- mean
#     sigma <- sqrt(var)
#     return(list(mu, sigma))
#     } else if (dist == "lnorm") {
#     meanlog <- log(mean) - log(1 + var/(mean^2))/2
#     sdlog <- sqrt(log(1 + var/(mean^2)))
#     return(list(meanlog, sdlog))
#     }
# }

expected_max_fromsim <- function(distr, n, mean, variance) {
  if (distr == "gamma") {
    par1 <- (mean^2) / variance # shape
    par2 <- mean / variance # rate (= 1/scale)
  } else if (distr == "tnorm") {
    par1 <- mean # mu
    par2 <- sqrt(variance) # sigma
  } else if (distr == "lnorm") {
    par1 <- log(mean) - log(1 + variance / (mean^2)) / 2 # meanlog
    par2 <- sqrt(log(1 + variance / (mean^2)))
  }
  est_max <- expected_max(dist = distr, n = n, par1 = par1, par2 = par2)
  return(est_max)
}

expected_max_evt <- function(loc, scale, shape, k) {
  evd::qgev(1 - (1 / k), loc = loc, scale = scale, shape = shape)
}

# calc_max <- function(x, n, mu, sigma) {
#     fx <- dtnorm(x, mean = mu, sd = sigma)
#     Fx <- ptnorm(x, mean = mu, sd = sigma)
#     max <- (n * (Fx^(n - 1))) * fx
#     return(max)
# }

# cdf_max <- function(x, distr, n, par1, par2) {
#   cdf <- function(x) get(paste0("p", distr))(x, par1, par2)
#   cdf(x)^n
# }

# this is 'brute force' approach to estimate expected maximum for any of the distributions
# mainly just for testing the expected_max function
expected_max_brute <- function(distr, par1, par2, n, iterations = 1000) {
  sample_func <- function(n, par1, par2) get(paste0("r", distr))(n, par1, par2)
  mean(replicate(iterations, max(sample_func(n = n, par1, par2))))
}

# pdf_max_gev <- function(x, k, loc, scale, shape) {
#   pdf <- function(x) dgev(x, loc, scale, shape)
#   cdf <- function(x) pgev(x, loc, scale, shape)
#   # avoiding very small pdf and cdf values
#   log_pdf_max <- log(k) + (k - 1) * log(cdf(x)) + log(pdf(x))
#   exp(log_pdf_max)
# }

# expected_max_gev <- function(k, loc, scale, shape) {
#   integrand <- function(x) x * pdf_max_gev(x, k, loc, scale, shape)
#   upper_bound <- qgev(0.9999999999999, loc, scale, shape)
#   integrate(integrand, lower = 0, upper = upper_bound, rel.tol = 1e-6)$value
# }
