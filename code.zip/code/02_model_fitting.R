source("code/00a_truncnorm_functions.R")
source("code/00b_model_functions.R")
source("code/00c_expectedmax_functions.R")
source("code/01_simulation.R")
# library(tidyverse)
library(future)
library(furrr)
library(stringr)

scenarios_truemax <-
  input_scenarios |>
  dplyr::mutate(
    true_max = purrr::pmap_dbl(
      .l = list(
        distr = dist,
        n = k * n_lambda,
        mean = mean,
        variance = variance
      ),
      .f = expected_max_fromsim
    ),
    true_max20 = purrr::pmap_dbl(
      .l = list(
        distr = dist,
        n = 100 * n_lambda,
        mean = mean,
        variance = variance
      ),
      .f = expected_max_fromsim
    )
  ) |>
  dplyr::select(scenario_input, true_max, true_max20)

posterior_filename <- "data/model_output/posteriors.parquet"
if (!file.exists(posterior_filename)) {
  future::plan(multisession)
  scenarios_maxima |>
    tidyr::expand_grid(model_scenarios) |>
    dplyr::mutate(filename = paste0(scenario_input, "_", scenario_model)) |>
    tidyr::nest(.by = filename) |>
    dplyr::left_join(scenarios) |>
    dplyr::mutate(maxima = map(data, ~ .x$sample_max)) |>
    dplyr::mutate(
      model_posterior = furrr::future_pmap(
        .l = list(
          maxima = maxima,
          type = type,
          gamma_shape = gamma_shape,
          gamma_rate = gamma_rate
        ),
        .f = fit_maxima_model,
        .options = furrr_options(seed = TRUE)
      )
    ) |>
    dplyr::select(filename, model_posterior) |>
    dplyr::unnest(cols = model_posterior) |>
    arrow::write_parquet(posterior_filename)
  future::plan(sequential)
}

posteriors <- arrow::read_parquet(posterior_filename)

posteriors_max_summary_path <- "data/model_summaries/posteriors_max_summary.csv"
if (!file.exists(posteriors_max_summary_path)) {
  posteriors_max_summary_evt <-
    posteriors |>
    dplyr::left_join(scenarios) |>
    dplyr::filter(stringr::str_detect(filename, "_evt$")) |>
    dplyr::mutate(
      est_max = purrr::pmap_dbl(
        .l = list(p = 1 - (1 / k), loc = loc, scale = scale, shape = shape),
        .f = evd::qgev
      ),
      est_max20 = purrr::pmap_dbl(
        .l = list(p = 1 - (1 / 20), loc = loc, scale = scale, shape = shape),
        .f = evd::qgev
      )
    ) |>
    dplyr::summarise(
      dplyr::across(
        c(est_max, est_max20),
        list(
          fit = median,
          lwr = ~ quantile(.x, 0.025),
          upr = ~ quantile(.x, 0.975)
        )
      ),
      .by = filename
    )

  posteriors_max_summary_efs <-
    posteriors |>
    dplyr::left_join(scenarios) |>
    dplyr::filter(stringr::str_detect(filename, "_efs_")) |>
    dplyr::mutate(
      est_max = purrr::pmap_dbl(
        .l = list(
          p = 1 - (1 / k),
          distr = "tnorm",
          par1 = mu,
          par2 = sigma,
          n = lambda * k
        ),
        .f = inverse_G_x
      ),
      est_max20 = purrr::pmap_dbl(
        .l = list(
          p = 1 - (1 / 20),
          distr = "tnorm",
          par1 = mu,
          par2 = sigma,
          n = lambda * 20
        ),
        .f = inverse_G_x
      )
    ) |>
    dplyr::summarise(
      dplyr::across(
        c(est_max, est_max20),
        list(
          fit = median,
          lwr = ~ quantile(.x, 0.025),
          upr = ~ quantile(.x, 0.975)
        )
      ),
      .by = filename
    )

  dplyr::bind_rows(posteriors_max_summary_evt, posteriors_max_summary_efs) |>
    readr::write_csv(posteriors_max_summary_path)
} else {
  posteriors_max_summary <- readr::read_csv(
    posteriors_max_summary_path,
    show_col_types = FALSE
  )
}
