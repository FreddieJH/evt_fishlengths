# Figure 1: Conceptual figure comparing the two methods of estimating maximum length of a fish

# Script requirements  --------------------------------------------------------------

source("code/02_simulation.R")
source("code/00b_model_functions.R")
source("code/00c_expectedmax_functions.R")
library(tidyverse)
library(evd)
library(geomtextpath)
library(patchwork)

# Script parameters  --------------------------------------------------------------

# Choosing scenario parameters for the example
scenario1_k <- 50
scenario1_lambda <- 1000
scenario1_mean <- 50
scenario1_variance <- (scenario1_mean * 0.34)^2

evt_colour <- "orange"
efs_colour <- "pink"
efs_colour_dark <- "#f66b6b"

# Scenario calculations  --------------------------------------------------------------

scenario1 <-
    scenarios %>%
    filter(
        k == scenario1_k,
        n_lambda == scenario1_lambda,
        mean == scenario1_mean,
        dist == "tnorm"
    ) %>%
    filter(str_detect(filename, "shape16|evt"))

scenario1_maxima <-
    scenarios_maxima %>%
    filter(scenario_input %in% scenario1$scenario_input) %>%
    pull(sample_max)

scenario1_n <-
    scenarios_maxima %>%
    filter(scenario_input %in% scenario1$scenario_input) %>%
    pull(sample_n)

scenario1_posterior_max_summary <-
    posteriors_max_summary %>%
    filter(filename %in% scenario1$filename)

scenario1_posterior_max_summary_evt <-
    scenario1_posterior_max_summary %>%
    filter(str_detect(filename, "_evt$"))

scenario1_posterior_max_summary_efs <-
    scenario1_posterior_max_summary %>%
    filter(str_detect(filename, "_efs"))

scenario1_evt_cdf_summary_path <- "data/model_summaries/scenario1_evt_cdf_summary.csv"
if (!file.exists(scenario1_evt_cdf_summary_path)) {
    scenario1_evt_cdf_summary <-
        posteriors %>%
        filter(filename %in% scenario1$filename) %>%
        filter(str_detect(filename, "_evt$")) |>
        expand_grid(size = 0:180) |>
        mutate(
            cdf = pmap_dbl(
                .l = list(q = size, loc = loc, scale = scale, shape = shape),
                .f = evd::pgev
            )
        ) |>
        summarise(
            p_fit = quantile(cdf, 0.5),
            p_lwr = quantile(cdf, 0.025),
            p_upr = quantile(cdf, 0.975),
            .by = size
        )

    write_csv(scenario1_evt_cdf_summary, scenario1_evt_cdf_summary_path)
} else {
    scenario1_evt_cdf_summary <- read_csv(
        scenario1_evt_cdf_summary_path,
        show_col_types = FALSE
    )
}

scenario1_efs_summary_path <- "data/model_summaries/scenario1_efs_cdf_summary.csv"
if (!file.exists(scenario1_efs_summary_path)) {
    scenario1_efs_cdf_summary <-
        posteriors %>%
        filter(filename %in% scenario1$filename) %>%
        filter(str_detect(filename, "_efs")) |>
        expand_grid(size = 0:180) |>
        mutate(
            cdf = pmap_dbl(
                .l = list(
                    x = size,
                    distr = "tnorm",
                    n = lambda * 20,
                    par1 = mu,
                    par2 = sigma
                ),
                .f = G_max
            )
        ) |>
        summarise(
            p_fit = quantile(cdf, 0.5),
            p_lwr = quantile(cdf, 0.025),
            p_upr = quantile(cdf, 0.975),
            .by = size
        )

    write_csv(scenario1_efs_cdf_summary, scenario1_efs_summary_path)
} else {
    scenario1_efs_cdf_summary <- read_csv(
        scenario1_efs_summary_path,
        show_col_types = FALSE
    )
}

# expected maximum based on 20 samples, each of length 200 (total is 20*1000 samples)
scenario1_max <- expected_max_fromsim(
    dist = "tnorm",
    n = scenario1_k * scenario1_lambda,
    mean = scenario1_mean,
    variance = scenario1_variance
)
scenario1_max20 <- expected_max_fromsim(
    dist = "tnorm",
    n = (20 * scenario1_lambda),
    mean = scenario1_mean,
    variance = scenario1_variance
)

# Figure 2  ------------------------------------------------------------------------------

p_scenario1_underlying <-
    ggplot() +
    geom_textdensity(
        aes(x),
        data = tibble(
            x = rtnorm(
                1e6,
                a = 0,
                mean = scenario1_mean,
                sd = sqrt(scenario1_variance)
            )
        ),
        label = "Observable body size distribution",
        hjust = 0.4
    ) +
    geom_rect(
        aes(
            xmin = scenario1_posterior_max_summary_evt$est_max20_lwr,
            xmax = scenario1_posterior_max_summary_evt$est_max20_upr,
            ymin = -Inf,
            ymax = Inf
        ),
        fill = evt_colour,
        alpha = 0.3
    ) +
    geom_rect(
        aes(
            xmin = scenario1_posterior_max_summary_efs$est_max20_lwr,
            xmax = scenario1_posterior_max_summary_efs$est_max20_upr,
            ymin = -Inf,
            ymax = Inf
        ),
        fill = efs_colour,
        alpha = 0.3
    ) +
    geom_textvline(
        aes(xintercept = scenario1_posterior_max_summary_efs$est_max20_fit),
        color = efs_colour_dark,
        linetype = "dashed",
        label = as.character(expression(L[paste(max, ", ", 20)])),
        parse = TRUE,
        size = 5
    ) +
    geom_textvline(
        aes(xintercept = scenario1_posterior_max_summary_evt$est_max20_fit),
        color = evt_colour,
        linetype = "dashed",
        label = as.character(expression(L[paste(max, ", ", 20)])),
        parse = TRUE,
        size = 5
    ) +
    geom_rug(
        aes(x = scenario1_maxima),
        color = "purple",
        length = unit(0.5, units = "cm")
    ) +
    geom_point(aes(x = scenario1_max20, y = 0), size = 4) +
    labs(x = "Fish body length (cm)", y = NULL) +
    theme_minimal(20) +
    theme(
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank()
    ) +
    scale_x_continuous(breaks = seq(40, 150, 20), expand = c(0, 1)) +
    coord_cartesian(xlim = c(40, 150))

p1_lims <- layer_scales(p_scenario1_underlying)$x$range$range

# scenario1_plotting <-
#     scenario1 |>
#     mutate(plotting_pos = rank(scenario1_maxima) / (max(rank(scenario1_maxima)) + 1))

plot_modfit <- function(type, colour, data_colour = "purple", k = 20) {
    posterior <- get(paste0("scenario1_", type, "_cdf_summary"))
    est_summary <- get(paste0("scenario1_posterior_max_summary_", type))

    est_max20_fit <- est_summary$est_max20_fit
    est_max20_lwr <- est_summary$est_max20_lwr
    est_max20_upr <- est_summary$est_max20_upr

    ggplot(posterior) +
        geom_ribbon(
            aes(x = size, ymin = p_lwr, ymax = p_upr),
            fill = colour,
            alpha = 0.3
        ) +
        # geom_point(aes(x = scenario1_maxima, y = plotting_pos, size = n), data = scenario1_plotting, color = data_colour) +
        geom_rug(
            aes(x = scenario1_maxima),
            color = "purple",
            length = unit(1, units = "cm"),
            linewidth = 2,
            data = tibble()
        ) +
        geom_line(aes(x = size, y = p_fit), col = colour, linewidth = 1.5) +
        geom_errorbarh(
            aes(xmin = est_max20_lwr, xmax = est_max20_upr, y = 1 - (1 / k)),
            height = 0.03,
            col = "black",
            lty = "solid",
            data = tibble(n = 1)
        ) +
        geom_vline(xintercept = est_max20_fit, col = colour, lty = "dashed") +
        labs(
            x = "Fish body length (cm)",
            y = "Pr(Lmax < size)",
            size = "Sample size"
        ) +
        theme_minimal(20) +
        theme(
            legend.position = "inside",
            legend.position.inside = c(0.05, 1),
            legend.justification = c(0, 1.2),
            legend.background = element_rect(fill = "white", color = "black")
        ) +
        scale_x_continuous(breaks = seq(40, 150, 20), expand = c(0, 1)) +
        coord_cartesian(xlim = c(40, 150))
}

p_scenario1_evt <- plot_modfit(type = "evt", colour = "orange")
p_scenario1_efs <- plot_modfit(type = "efs", colour = "pink")

p_examplefit <-
    p_scenario1_underlying +
    p_scenario1_evt +
    p_scenario1_efs +
    plot_layout(ncol = 1, axis_titles = "collect") +
    plot_annotation(tag_levels = "A")

ggsave(
    filename = "results/figures/p_examplefit.png",
    plot = p_examplefit,
    height = 12,
    width = 10
)
